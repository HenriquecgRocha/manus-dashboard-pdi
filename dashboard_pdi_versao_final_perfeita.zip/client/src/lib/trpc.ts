// tRPC desativado - Usando Firebase Realtime Database
export const trpc = {} as any;
