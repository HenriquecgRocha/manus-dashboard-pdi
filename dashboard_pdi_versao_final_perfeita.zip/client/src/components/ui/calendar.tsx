export function Calendar() {
  return <div>Calendário desativado</div>;
}

export function CalendarDayButton() {
  return null;
}
